/// Shared spacing, sizing, and radius constants.
/// Source: UI/UX Design Spec, Section 1 — Buttons, Iconography, Accessibility.
class AppDimensions {
  AppDimensions._();

  // Spacing scale
  static const double spaceXS = 4;
  static const double spaceS = 8;
  static const double spaceM = 16;
  static const double spaceL = 24;
  static const double spaceXL = 32;
  static const double spaceXXL = 48;

  // Buttons — minimum 56dp height per spec, non-negotiable for 50+ audience
  static const double buttonHeight = 56;
  static const double buttonRadius = 12;

  // Touch targets — accessibility minimum
  static const double minTouchTarget = 48;

  // Card / surface
  static const double cardRadius = 16;
  static const double cardElevation = 2;

  // Source-selection option cards (Screen 2)
  static const double optionCardHeight = 100;

  // Animation durations — "subtle and slow", never bouncy
  static const Duration animationFast = Duration(milliseconds: 250);
  static const Duration animationSlow = Duration(milliseconds: 350);
}
