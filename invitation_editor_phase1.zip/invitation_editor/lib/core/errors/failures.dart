import 'package:equatable/equatable.dart';

/// Base type for all "something went wrong" cases across the app.
/// Kept deliberately minimal for Phase 1 — no business logic yet.
abstract class Failure extends Equatable {
  final String message;

  const Failure(this.message);

  @override
  List<Object?> get props => [message];
}

class FileLoadFailure extends Failure {
  const FileLoadFailure([super.message = 'Could not load the file.']);
}

class StorageFailure extends Failure {
  const StorageFailure([super.message = 'Could not save your data.']);
}

class UnknownFailure extends Failure {
  const UnknownFailure([super.message = 'Something went wrong.']);
}
