import 'package:go_router/go_router.dart';
import '../features/library/presentation/screens/library_screen.dart';
import '../features/source_selection/presentation/screens/source_selection_screen.dart';
import '../features/templates/presentation/screens/template_library_screen.dart';
import '../features/editor/presentation/screens/editor_screen.dart';
import '../features/export/presentation/screens/export_screen.dart';
import '../features/settings/presentation/screens/settings_screen.dart';

/// Central place listing every screen and how to navigate between them.
/// Phase 1: routes exist and are reachable, but only the Library
/// (Home) screen has real UI — the rest are placeholders.
class AppRouter {
  AppRouter._();

  static final GoRouter router = GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        name: 'library',
        builder: (context, state) => const LibraryScreen(),
      ),
      GoRoute(
        path: '/new-invitation',
        name: 'sourceSelection',
        builder: (context, state) => const SourceSelectionScreen(),
      ),
      GoRoute(
        path: '/templates',
        name: 'templates',
        builder: (context, state) => const TemplateLibraryScreen(),
      ),
      GoRoute(
        path: '/editor',
        name: 'editor',
        builder: (context, state) => const EditorScreen(),
      ),
      GoRoute(
        path: '/export',
        name: 'export',
        builder: (context, state) => const ExportScreen(),
      ),
      GoRoute(
        path: '/settings',
        name: 'settings',
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
  );
}
