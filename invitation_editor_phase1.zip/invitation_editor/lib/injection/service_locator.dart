import 'package:get_it/get_it.dart';

/// Wires the layers together (repositories, use-cases, etc.).
/// Left intentionally empty for Phase 1 — no repositories or
/// use-cases exist yet. Called once from main() so the wiring
/// point already exists for later phases.
final GetIt sl = GetIt.instance;

Future<void> setupServiceLocator() async {
  // Registrations will be added feature-by-feature in later phases.
}
