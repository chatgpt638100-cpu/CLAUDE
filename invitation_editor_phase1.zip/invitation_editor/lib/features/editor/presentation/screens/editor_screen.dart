import 'package:flutter/material.dart';
import '../../../../core/widgets/app_bar_widget.dart';

/// Screen 4 — The Editor.
/// Placeholder only — canvas, formatting panel, and voice typing
/// are explicitly out of scope for this phase.
class EditorScreen extends StatelessWidget {
  const EditorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'Editor', showBackLabel: true),
      body: const Center(child: Text('Editor — coming in a later phase')),
    );
  }
}
