import 'package:flutter/material.dart';
import '../../../../core/widgets/app_bar_widget.dart';

/// Screen 2 — New Invitation (Source Selection).
/// Placeholder only — content to be built in a later phase.
class SourceSelectionScreen extends StatelessWidget {
  const SourceSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'New Invitation', showBackLabel: true),
      body: const Center(child: Text('Source Selection — coming in a later phase')),
    );
  }
}
