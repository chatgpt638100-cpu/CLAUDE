import 'package:flutter/material.dart';
import '../../../../core/widgets/app_bar_widget.dart';
import '../../domain/entities/invitation_source_file.dart';

/// Screen 4 — The Editor.
/// Placeholder only — canvas, formatting panel, and voice typing
/// are explicitly out of scope for this phase.
///
/// [sourceFile] is received from the Source Selection screen (when the
/// user picked a PDF or image) but is intentionally not displayed or
/// processed yet.
class EditorScreen extends StatelessWidget {
  final InvitationSourceFile? sourceFile;

  const EditorScreen({super.key, this.sourceFile});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'Editor', showBackLabel: true),
      body: const Center(child: Text('Editor — coming in a later phase')),
    );
  }
}
